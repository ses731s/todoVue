<template>
  <div class="main-wrapper">
    <h1>404 | Page Not Found</h1>
  </div>
</template>

<script>
export default {
  name: "PageNotFound"
};
</script>

<style scoped>
.main-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 60%;
}
</style>
